# Credits

Deutsch:
Foto Jan Bolomey für republik.ch

Englisch:
Photo by Jan Bolomey for republik.ch

# Bildbeschriebe

## crowdfunding_republik_schlange1.jpg, crowdfunding_republik_schlange2.jpg, crowdfunding_republik_schlange3.jpg

Über 200 Leute stehen um 7 Uhr morgens vor dem Hotel Rothaus an, um zu den Ersten zu gehören, die eine Republik Mitgliedschaft lösen. 

## crowdfunding_republik_erste_mitglieder1.jpg, crowdfunding_republik_erste_mitglieder2.jpg

Grosser Ansturm im Hotel Rothaus, um Mitglied bei Republik zu werden.

## crowdfunding_republik_seibt_mit_unterstuetzer.jpg

Jacqueline Badran macht ein Foto von Patrick Frey, Daniel Meili, Viktor Giacobbo, Constantin Seibt beim Start des Republik Crowdfunding im Hotel Rothaus. Im Hintergrund Oliver Claasen.

